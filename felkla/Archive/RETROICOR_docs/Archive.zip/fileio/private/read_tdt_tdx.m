function tdx = read_tdt_tdx(filename, begblock, endblock)

% tdx file contains just information about epoc,
% is generated after recording if necessary for fast retrieve epoc information
