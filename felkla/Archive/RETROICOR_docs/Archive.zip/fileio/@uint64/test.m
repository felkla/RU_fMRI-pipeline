%
% perform a quick sanity check
%

uint64(4)  + uint64(2)
uint64(4)  - uint64(2)
uint64(4) ./ uint64(2)
uint64(4) .* uint64(2)

