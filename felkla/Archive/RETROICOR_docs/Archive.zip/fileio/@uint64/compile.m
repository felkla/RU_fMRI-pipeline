mex abs.c
mex max.c
mex min.c
mex minus.c
mex plus.c
mex rdivide.c
mex times.c
